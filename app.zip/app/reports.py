import csv
import os
from database import JSONDatabase

def export_students_csv(target_path="exports/estudiantes.csv"):
    os.makedirs(os.path.dirname(target_path), exist_ok=True)
    db = JSONDatabase()
    students = db.list_students()
    with open(target_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["Nombre", "Grado"])
        for s in students:
            w.writerow([s.get("nombre", ""), s.get("grado", "")])
    return target_path

def export_attendance_csv(target_path="exports/asistencias.csv"):
    os.makedirs(os.path.dirname(target_path), exist_ok=True)
    db = JSONDatabase()
    regs = db.list_attendances()
    with open(target_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["Fecha", "Estudiante", "Estado"])
        for r in regs:
            w.writerow([r.get("fecha",""), r.get("estudiante",""), r.get("estado","")])
    return target_path

def export_all_excel(target_path="exports/reporte.xlsx"):
    try:
        import openpyxl
        from openpyxl.utils import get_column_letter
    except Exception:
        return None  # no openpyxl available

    os.makedirs(os.path.dirname(target_path), exist_ok=True)
    db = JSONDatabase()
    students = db.list_students()
    regs = db.list_attendances()

    wb = openpyxl.Workbook()
    ws1 = wb.active
    ws1.title = "Estudiantes"
    ws1.append(["Nombre", "Grado"])
    for s in students:
        ws1.append([s.get("nombre",""), s.get("grado","")])

    ws2 = wb.create_sheet("Asistencias")
    ws2.append(["Fecha","Estudiante","Estado"])
    for r in regs:
        ws2.append([r.get("fecha",""), r.get("estudiante",""), r.get("estado","")])

    wb.save(target_path)
    return target_path