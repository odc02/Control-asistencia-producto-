import flet as ft
from controllers import StudentController, AttendanceController
from themes import themed_button, info_dialog

# ---------- FUNCIÓN GLOBAL: Cambiar Tema ----------
def toggle_theme(page: ft.Page):
    page.theme_mode = (
        ft.ThemeMode.DARK if page.theme_mode == ft.ThemeMode.LIGHT else ft.ThemeMode.LIGHT
    )
    page.update()

# ---------- BOTÓN UNIVERSAL DE REGRESO ----------
def back_button(page):
    return ft.IconButton(
        icon=ft.icons.ARROW_BACK,
        tooltip="Volver al inicio",
        on_click=lambda e: page.go("/")
    )

# ---------- BOTÓN MODO OSCURO / CLARO ----------
def theme_button(page):
    return ft.IconButton(
        icon=ft.icons.DARK_MODE if page.theme_mode == ft.ThemeMode.LIGHT else ft.icons.LIGHT_MODE,
        tooltip="Cambiar tema",
        on_click=lambda e: toggle_theme(page)
    )


# ----------------------------------------------------
#                   HOME / MENU
# ----------------------------------------------------
class MainMenu(ft.View):
    def __init__(self, page: ft.Page):
        super().__init__(route="/")
        self.page = page

        self.controls = [
            ft.Row(
                controls=[theme_button(page)],
                alignment=ft.MainAxisAlignment.END
            ),
            ft.Column(
                [
                    ft.Text("Control de Asistencia", size=36, weight=ft.FontWeight.BOLD),
                    ft.Row([
                        themed_button("Registrar estudiante", lambda e: page.go("/registrar"),
                                      icon=ft.Icon(ft.icons.PERSON_ADD)),
                        themed_button("Lista de estudiantes", lambda e: page.go("/estudiantes"),
                                      icon=ft.Icon(ft.icons.LIST)),
                        themed_button("Registrar asistencia", lambda e: page.go("/asistencia"),
                                      icon=ft.Icon(ft.icons.CHECK)),
                        themed_button("Reportes", lambda e: page.go("/reportes"),
                                      icon=ft.Icon(ft.icons.INSIGHTS)),
                    ], spacing=12)
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=20,
                expand=True
            )
        ]


# ----------------------------------------------------
#             REGISTRAR ESTUDIANTE
# ----------------------------------------------------
class RegistrarView(ft.View):
    def __init__(self, page: ft.Page):
        super().__init__(route="/registrar")
        self.page = page
        self.ctrl = StudentController()

        self.tf_nombre = ft.TextField(label="Nombre", width=400)
        self.tf_grado = ft.TextField(label="Grado", width=400)

        def guardar(e):
            nombre = self.tf_nombre.value.strip()
            grado = self.tf_grado.value.strip()

            if not nombre or not grado:
                page.snack_bar = ft.SnackBar(content=ft.Text("Completa todos los campos"), open=True)
                page.update()
                return

            self.ctrl.create(nombre, grado)

            page.snack_bar = ft.SnackBar(content=ft.Text("Estudiante guardado"), open=True)
            self.tf_nombre.value = ""
            self.tf_grado.value = ""
            page.update()

        self.controls = [
            ft.Row([back_button(page), theme_button(page)]),
            ft.Text("Registrar Estudiante", size=28, weight=ft.FontWeight.BOLD),
            self.tf_nombre,
            self.tf_grado,
            themed_button("Guardar", guardar, icon=ft.Icon(ft.icons.SAVE))
        ]


# ----------------------------------------------------
#          LISTA / BUSCAR / EDITAR / ELIMINAR
# ----------------------------------------------------
class EstudiantesView(ft.View):
    def __init__(self, page: ft.Page):
        super().__init__(route="/estudiantes")
        self.page = page
        self.ctrl = StudentController()

        self.buscar = ft.TextField(
            hint_text="Buscar estudiante por nombre",
            on_change=self._build,
            width=400
        )

        self.container = ft.Column()

        self._build()

        self.controls = [
            ft.Row([back_button(page), theme_button(page)]),
            ft.Text("Estudiantes", size=28, weight=ft.FontWeight.BOLD),
            self.buscar,
            self.container
        ]

    def _build(self, e=None):
        texto = self.buscar.value.lower() if self.buscar.value else ""
        self.container.controls.clear()

        students = self.ctrl.list()

        # Filtrar
        if texto:
            students = [
                s for s in students
                if texto in s.get("nombre", "").lower()
            ]

        if not students:
            self.container.controls.append(ft.Text("No hay estudiantes"))
            return

        for idx, s in enumerate(students):
            fila = ft.Row([
                ft.Text(
                    f"{s.get('nombre','')} — Grado: {s.get('grado','')}",
                    expand=True
                ),

                ft.IconButton(
                    icon=ft.icons.EDIT,
                    icon_color="blue",
                    tooltip="Editar",
                    on_click=lambda e, i=idx: self._edit(i)
                ),

                ft.IconButton(
                    icon=ft.icons.DELETE,
                    icon_color="red",
                    tooltip="Eliminar",
                    on_click=lambda e, i=idx: self._delete(i)
                )
            ])
            self.container.controls.append(fila)

    def _edit(self, index):
        s = self.ctrl.list()[index]
        tfn = ft.TextField(value=s.get("nombre", ""), label="Nombre")
        tfg = ft.TextField(value=s.get("grado", ""), label="Grado")

        def save(e):
            self.ctrl.update(index, tfn.value, tfg.value)
            dlg.open = False
            self._build()
            self.page.update()

        dlg = ft.AlertDialog(
            title=ft.Text("Editar estudiante"),
            content=ft.Column([tfn, tfg]),
            actions=[
                ft.TextButton("Guardar", on_click=save),
                ft.TextButton("Cancelar", on_click=lambda e: close_dialog(self.page))
            ]
        )
        self.page.dialog = dlg
        dlg.open = True
        self.page.update()

    def _delete(self, index):
        def confirm_delete(e):
            self.ctrl.delete(index)
            dlg.open = False
            self._build()
            self.page.update()

        dlg = ft.AlertDialog(
            title=ft.Text("Confirmar"),
            content=ft.Text("¿Eliminar estudiante?"),
            actions=[
                ft.TextButton("Sí", on_click=confirm_delete),
                ft.TextButton("No", on_click=lambda e: close_dialog(self.page))
            ]
        )
        self.page.dialog = dlg
        dlg.open = True
        self.page.update()


def close_dialog(page):
    if getattr(page, "dialog", None):
        page.dialog.open = False
        page.update()


# ----------------------------------------------------
#              REGISTRAR ASISTENCIA
# ----------------------------------------------------
class AsistenciaView(ft.View):
    def __init__(self, page: ft.Page):
        super().__init__(route="/asistencia")
        self.page = page
        self.sctrl = StudentController()
        self.actrl = AttendanceController()

        nombres = self.sctrl.get_names()
        if not nombres:
            nombres = ["(no hay estudiantes)"]

        self.dd_est = ft.Dropdown(label="Seleccionar estudiante",
                                  options=[ft.dropdown.Option(n) for n in nombres], width=400)

        self.dd_estado = ft.Dropdown(
            label="Estado",
            options=[
                ft.dropdown.Option("Presente"),
                ft.dropdown.Option("Faltante"),
                ft.dropdown.Option("Justificado")
            ],
            width=400
        )

        def guardar(e):
            est = self.dd_est.value
            estado = self.dd_estado.value

            if not est or est == "(no hay estudiantes)":
                self.page.snack_bar = ft.SnackBar(
                    content=ft.Text("Registra estudiantes primero"), open=True
                )
                self.page.update()
                return

            if not estado:
                self.page.snack_bar = ft.SnackBar(
                    content=ft.Text("Selecciona un estado"), open=True
                )
                self.page.update()
                return

            self.actrl.register(est, estado)
            self.page.snack_bar = ft.SnackBar(
                content=ft.Text("Asistencia registrada"), open=True
            )
            self.page.update()

        self.controls = [
            ft.Row([back_button(page), theme_button(page)]),
            ft.Text("Registrar Asistencia", size=28, weight=ft.FontWeight.BOLD),
            self.dd_est,
            self.dd_estado,
            themed_button("Guardar asistencia", guardar)
        ]


# ----------------------------------------------------
#               REPORTES + FILTRO POR FECHA
# ----------------------------------------------------
class ReportesView(ft.View):
    def __init__(self, page: ft.Page):
        super().__init__(route="/reportes")
        self.page = page
        self.actrl = AttendanceController()

        self.tf_fecha = ft.TextField(label="Fecha (YYYY-MM-DD)", width=250)
        self.col_lista = ft.Column()

        def filtrar(e):
            fecha = self.tf_fecha.value.strip()
            if not fecha:
                regs = self.actrl.list()
            else:
                regs = self.actrl.list(fecha)

            self.col_lista.controls.clear()
            if not regs:
                self.col_lista.controls.append(ft.Text("No hay registros para esa fecha."))
            else:
                for r in regs:
                    self.col_lista.controls.append(
                        ft.Text(f"{r.get('fecha','')} — {r.get('estudiante','')} — {r.get('estado','')}")
                    )
            self.page.update()

        self.controls = [
            ft.Row([back_button(page), theme_button(page)]),
            ft.Text("Reportes y filtro por fecha", size=28, weight=ft.FontWeight.BOLD),
            ft.Row([self.tf_fecha, themed_button("Filtrar", filtrar)]),
            self.col_lista
        ]


# Router
def router(page: ft.Page):
    return {
        "/": MainMenu(page),
        "/registrar": RegistrarView(page),
        "/estudiantes": EstudiantesView(page),
        "/asistencia": AsistenciaView(page),
        "/reportes": ReportesView(page),
    }