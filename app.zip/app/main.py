import flet as ft
from views import router

def main(page: ft.Page):
    page.title = "Control de Asistencia"
    page.theme_mode = ft.ThemeMode.LIGHT

    def route_change(e):
        page.views.clear()
        page.views.append(router(page)[page.route])
        page.update()

    def view_pop(e):
        page.views.pop()
        page.go(page.views[-1].route)

    page.on_route_change = route_change
    page.on_view_pop = view_pop

    page.go("/")

if __name__ == "__main__":
    ft.app(target=main)