import json
import os
from datetime import datetime

class JSONDatabase:
    def __init__(self, file_name="data.json"):
        # file is located inside the same folder as this file
        self.path = os.path.join(os.path.dirname(__file__), file_name)
        if not os.path.exists(self.path):
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump({"estudiantes": [], "asistencias": []}, f, indent=4, ensure_ascii=False)

    def _read_all(self):
        with open(self.path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _write_all(self, data):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

    # estudiantes
    def list_students(self):
        return self._read_all().get("estudiantes", [])

    def add_student(self, student_dict):
        data = self._read_all()
        data["estudiantes"].append(student_dict)
        self._write_all(data)

    def update_student(self, index, new_student):
        data = self._read_all()
        data["estudiantes"][index] = new_student
        self._write_all(data)

    def delete_student(self, index):
        data = self._read_all()
        data["estudiantes"].pop(index)
        self._write_all(data)

    # asistencias
    def add_attendance(self, registro):
        # registro should be a dict with 'estudiante', 'estado' and optional 'fecha'
        d = self._read_all()
        if "fecha" not in registro:
            registro["fecha"] = datetime.now().strftime("%Y-%m-%d")
        d.setdefault("asistencias", []).append(registro)
        self._write_all(d)

    def list_attendances(self, fecha=None):
        all_data = self._read_all().get("asistencias", [])
        if fecha:
            # filter by exact fecha string e.g. '2025-12-11'
            return [r for r in all_data if r.get("fecha") == fecha]
        return all_data