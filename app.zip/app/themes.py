import flet as ft

def themed_button(label, on_click=None, icon=None):
    # avoid referencing ft.colors to prevent API mismatch
    return ft.ElevatedButton(text=label, icon=icon, on_click=on_click)

def info_dialog(page: ft.Page, title, message):
    dlg = ft.AlertDialog(title=ft.Text(title), content=ft.Text(message), actions=[ft.TextButton("OK", on_click=lambda e: close_dialog(page))])
    page.dialog = dlg
    dlg.open = True
    page.update()

def close_dialog(page: ft.Page):
    if getattr(page, "dialog", None):
        page.dialog.open = False
        page.update()