from database import JSONDatabase
from models import Estudiante

class StudentController:
    def __init__(self):
        self.db = JSONDatabase()

    def list(self):
        return self.db.list_students()

    def create(self, nombre, grado):
        est = Estudiante(nombre=nombre.strip(), grado=grado.strip())
        self.db.add_student(est.to_dict())

    def update(self, index, nombre, grado):
        est = Estudiante(nombre=nombre.strip(), grado=grado.strip())
        self.db.update_student(index, est.to_dict())

    def delete(self, index):
        self.db.delete_student(index)

    def get_names(self):
        return [s.get("nombre") for s in self.db.list_students()]

class AttendanceController:
    def __init__(self):
        self.db = JSONDatabase()

    def register(self, estudiante, estado, fecha=None):
        registro = {"estudiante": estudiante, "estado": estado}
        if fecha:
            registro["fecha"] = fecha
        self.db.add_attendance(registro)

    def list(self, fecha=None):
        return self.db.list_attendances(fecha)