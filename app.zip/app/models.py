# simple model helpers (not required but handy)
from dataclasses import dataclass, asdict

@dataclass
class Estudiante:
    nombre: str
    grado: str

    def to_dict(self):
        return asdict(self)